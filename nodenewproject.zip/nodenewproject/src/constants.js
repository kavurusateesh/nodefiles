module.exports = {
    siteurl: 'http://localhost:8080/'
}