import React, {Component} from 'react';
import Login from './Login';

var Constant = require('../constants');

export default class Dashboard extends Component {
    constructor(props){
        super(props);
        this.state = {
        
           userName : localStorage.getItem("UserName"),
           Password : localStorage.getItem("password"),
           validated : localStorage.getItem("validated")
        }
       // 
    }
    // componentWillMount() {
    //     console.log(this.state);
    //     if (this.state.validated ==null) {
    //       this.props.history.push(`/`); 
    //     }
    //    // localStorage.clear();
    // }
    
    render(){
     
              
        return (
            <section id="main_dashboard">
            <div className="container" id="main_front">
            
            <div className="row">
            <div className="col-md-12">
            <div className="dash-section">
            
            <div className="section-header">
            <h3>Dashboard</h3>
            <ol className="breadcrumb">
            <li className="active">Dashboard</li>
            </ol>
            </div>
            
            
            </div>
            <div className="dash_content">
            <div className="row">
            
            <div className="col-md-3">
            <div className="doc_info_box">
            <span className="info-box-icon bg-red"><i className="fa fa-user-md"></i></span>
            <div className="info_box_content">
            <a href="ClinicList" className="dash_content_item">
            <span className="info-box-text">Clinics</span>
            <span className="info-box-number" >12</span>
            </a>
            </div>
            </div>
            
            </div>
            <div className="col-md-3">
            <div className="doc_info_box">
            <span className="info-box-icon bg-aqua"><i className="fa fa-user-md"></i></span>
            <div className="info_box_content">
            <a href="UserList/doctor" className="dash_content_item">
            <span className="info-box-text">Doctors</span>
            <span className="info-box-number" >12</span>
            </a>
            </div>
            </div>
            
            </div>
          
            <div className="col-md-3">
            <div className="doc_info_box">
            <span className="info-box-icon bg-aqua"><i className="fa fa-user-md"></i></span>
            <div className="info_box_content">
            <a href="UserList/Staff" className="dash_content_item">
            <span className="info-box-text">Staffs</span>
            <span className="info-box-number" >12</span>
            </a>
            </div>
            </div>
            
            </div>
            <div className="col-md-3">
            <div className="doc_info_box">
            <span className="info-box-icon bg-red"><i className="fa fa-user-md"></i></span>
            <div className="info_box_content">
            <a href="UserList/Staff" className="dash_content_item">
            <span className="info-box-text">Front Desk</span>
            <span className="info-box-number" >12</span>
            </a>
            </div>
            </div>
            
            </div>
            </div>
            </div>
            </div>
            </div>
            
            </div>
            
            
            </section>
        )
    }
}
