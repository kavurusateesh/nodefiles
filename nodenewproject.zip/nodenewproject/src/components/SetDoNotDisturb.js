import React, {Component} from 'react';
import { Button, FormGroup, FormControl, FormLabel } from "react-bootstrap";
import DatePicker from "react-datepicker";
import setHours from "date-fns/setHours";
import setMinutes from "date-fns/setMinutes";
import "react-datepicker/dist/react-datepicker.css";
import Login from './Login';
import axios from 'axios';
import $ from "jquery";

var Constant = require('../constants');

export default class SetDoNotDisturb extends Component {
	constructor(props) {
		super(props);
		this.state = {
			name: '',
			monday: '',
			tuesday: '',
			wednesday: '',
			thursday: '',
			friday: '',
			saturday: '',
			sunday: '',
			do_not_disturb_start_time: new Date(),
			do_not_disturb_end_time: new Date(),
		}
	}

	// When value changes of the fields
	handleChange = (event) => {
		this.setState({ [event.target.name]: event.target.checked });
	}

	// When value changes of the fields
	setStartTimeOnChange = value => {
		this.setState({ do_not_disturb_start_time: value });
	}

	// When value changes of the fields
	setEndTimeOnChange = value => {
		this.setState({ do_not_disturb_end_time: value });
	}

	// To get detais after first render
	componentDidMount = () => {
		const { handle } = this.props.match.params
		this.getDoctorInfo(handle);
	}

	// To get all the categories
	getDoctorInfo(handle) {
		axios.get(Constant.siteurl+'api/Doctors/'+handle)
		.then((response) => {
			var dndDays = response.data.do_not_disturb.split(',');
			for(var j=0; j<dndDays.length; j++) {
				dndDays[j] = (dndDays[j] == 1) ? "checked" : "";
			}
			var name = response.data.first_name+' '+response.data.last_name;
			var startTime = response.data.do_not_disturb_start_time.split(':');
			var endTime = response.data.do_not_disturb_end_time.split(':');
			var dateObject = new Date();
			this.setState({
				name: name,
				monday: dndDays[0],
				tuesday: dndDays[1],
				wednesday: dndDays[2],
				thursday: dndDays[3],
				friday: dndDays[4],
				saturday: dndDays[5],
				sunday: dndDays[6],
				do_not_disturb_start_time: setHours(setMinutes(dateObject, startTime[1]), startTime[0]),
				do_not_disturb_end_time: setHours(setMinutes(dateObject, endTime[1]), endTime[0]),
			});
		})
		.catch((error) => {
			console.log(error);
		})
	}

	// To add new category when user submits the form
	updateDoctorDoNotDisturb = (event) => {
		event.preventDefault();
		var handle = this.props.match.params.handle;
		const { monday, tuesday, wednesday, thursday, friday, saturday, sunday, do_not_disturb_start_time, do_not_disturb_end_time } = this.state;
		var mondayVal = (monday) ? 1 : 0;
		var tuesdayVal = (tuesday) ? 1 : 0;
		var wednesdayVal = (wednesday) ? 1 : 0;
		var thursdayVal = (thursday) ? 1 : 0;
		var fridayVal = (friday) ? 1 : 0;
		var saturdayVal = (saturday) ? 1 : 0;
		var sundayVal = (sunday) ? 1 : 0;
		var do_not_disturb = [mondayVal, tuesdayVal, wednesdayVal, thursdayVal, fridayVal, saturdayVal, sundayVal];
		do_not_disturb = do_not_disturb.join();
		axios.put(Constant.siteurl+'api/Doctors/'+handle, {
			do_not_disturb: do_not_disturb,
			do_not_disturb_start_time: do_not_disturb_start_time.getHours()+':'+do_not_disturb_start_time.getMinutes()+':00',
			do_not_disturb_end_time: do_not_disturb_end_time.getHours()+':'+do_not_disturb_end_time.getMinutes()+':00',
		})
		.then((response) => {
			window.location.reload();
			//this.props.history.push('/SetDoNotDisturb/'+handle);
		})
		.catch((error) => {
			console.log(error);
		});
		this.getDoctorInfo(handle);
	}

    render(){
		const { name, monday, tuesday, wednesday, thursday, friday, saturday, sunday, do_not_disturb_start_time, do_not_disturb_end_time } = this.state;
        return (
            <section id="main_dashboard">
				<div className="container" id="main_front">
					<div className="row">
						<div className="col-md-12">
							<div className="dash-section">
								<div className="section-header">
									<ol className="breadcrumb">
									<li className="active">Do Not Disturb timings for {name}</li>
									</ol>
								</div>
							</div>

							<section id="CMS_tab">
								<div className="CMS_content">
									<div className="container">
										<div className="row">
											<div className="tab-header">
												<h3>Do not Disturb timings for {name}</h3>
											</div>
											<div id="reg_form">
												<form onSubmit={this.updateDoctorDoNotDisturb}>
													<div className="row">
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Monday</label>
																<input type="checkbox" name="monday" checked={this.state.monday} onChange={this.handleChange} className="form-control" value={(this.state.monday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Tuesday</label>
																<input type="checkbox" name="tuesday" checked={this.state.tuesday} onChange={this.handleChange} className="form-control" value={(this.state.tuesday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Wednesday</label>
																<input type="checkbox" name="wednesday" checked={this.state.wednesday} onChange={this.handleChange} className="form-control" value={(this.state.wednesday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Thursday</label>
																<input type="checkbox" name="thursday" checked={this.state.thursday} onChange={this.handleChange} className="form-control" value={(this.state.thursday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Friday</label>
																<input type="checkbox" name="friday" checked={this.state.friday} onChange={this.handleChange} className="form-control" value={(this.state.friday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Saturday</label>
																<input type="checkbox" name="saturday" checked={this.state.saturday} onChange={this.handleChange} className="form-control" value={(this.state.saturday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
														<div className="col-md-1">
															<div className="form-group col-md-12">
																<label>Sunday</label>
																<input type="checkbox" name="sunday" checked={this.state.sunday} onChange={this.handleChange} className="form-control" value={(this.state.sunday=='checked')?1:0} placeholder="Enter category name" />
															</div>
														</div>
													</div>
													<div className="row">
														<div className="col-md-2">
															<div className="form-group col-md-12">
																<label>Start Time: </label> &nbsp; 
																<DatePicker name="do_not_disturb_start_time" selected={this.state.do_not_disturb_start_time} onChange={this.setStartTimeOnChange}  showTimeSelect showTimeSelectOnly timeIntervals={30} timeCaption="Time" dateFormat="hh:mm aa" className="form-control" />
															</div>
														</div>
														<div className="col-md-2">
															<div className="form-group col-md-12">
																<label>End Time: </label> &nbsp; 
																<DatePicker name="do_not_disturb_end_time" selected={this.state.do_not_disturb_end_time} onChange={this.setEndTimeOnChange} showTimeSelect showTimeSelectOnly timeIntervals={30} timeCaption="Time" dateFormat="hh:mm aa" className="form-control" />
															</div>
														</div>
														<div className="form-group col-md-2">
															<button type="submit" className="btn  btn-primary padTopCategorySave" >Save</button>
														</div>
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>
					</div>
				</div>
			</section>
        )
    }
}