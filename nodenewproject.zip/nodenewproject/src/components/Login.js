import React, { useState } from "react";
import { Button, FormGroup, FormControl, FormLabel } from "react-bootstrap";
import {withRouter} from 'react-router-dom';
import { createHashHistory } from "history";
import axios from 'axios';
//import "./Login.css";

var Constant = require('../constants');

export default function Login(props) {
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = useState("");
  const [validated, setValidate] = useState("");
  
  function validateForm() {
    return email.length > 0 && password.length > 0;
  }
  function handleSubmit(event) {
    const history = createHashHistory();
    event.preventDefault();
    if(email=='admin@cloud9.com' && password=='admin@123')
    {
      localStorage.setItem('UserName',email);
      localStorage.setItem('password',password);
      localStorage.setItem('validated',true);
      window.history.pushState("","","/Dashboard");
      window.location.reload();
    }else{
      localStorage.setItem('validated',false);
      document.getElementById("invalid").innerHTML = "Invalid Logins";
    }
   
  }
  
   // localStorage.clear();


  return (
    <div className="Login">
    
      <form onSubmit={handleSubmit}>
      <FormLabel id="invalid"></FormLabel>
        <FormGroup controlId="email" bsSize="large">
          <FormLabel>Email</FormLabel>
          <FormControl
            autoFocus
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
        </FormGroup>
        <FormGroup controlId="password" bsSize="large">
          <FormLabel>Password</FormLabel>
          <FormControl
            value={password}
            onChange={e => setPassword(e.target.value)}
            type="password"
          />
        </FormGroup>
        <Button block bsSize="large" disabled={!validateForm(this)} type="submit">
          Login
        </Button>
      </form>
    </div>
    
  );
}