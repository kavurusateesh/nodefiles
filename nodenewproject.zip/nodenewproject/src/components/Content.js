import React, {Component} from 'react';
import Login from './Login';
import Dashboard from './Dashboard'; 

import NotFound from './NotFound';
import { BrowserRouter, Switch, Route,Redirect } from "react-router-dom";

export default class Content extends Component {
constructor(props){
    super(props);
    if( localStorage.getItem("validated")) {
      
        const status=localStorage.getItem("validated");
        if(status==null) { status=false}
        this.state = {
              validated : status,
              module:null
        }
      }else{
        this.state = { 
          validated : false,
          module:null
    }
      }
      console.log(this.state.validated);
    }
  

    render(){
        return (

            <BrowserRouter>
           
            <Route path='/' exact strict render={() =>(
                    this.state.validated=true ? (<Dashboard />)  : (<Redirect to="/" />)
                )
            } />
             <Route path='/#'  render={() =>(
                    this.state.validated=true ? (<Dashboard />)  : (<Redirect to="/" />)
                )
            } />
            <Route path='/Login' exact strict render={() =>(
                    this.state.validated=true ? (<Dashboard />)  : (<Redirect to="/" />)
                )
            } />
            
            <Route path='/Dashboard' exact strict component={Dashboard}/>
            
            <Route path='/g' exact strict component={NotFound} />

            </BrowserRouter> 
             
        )
    }
}