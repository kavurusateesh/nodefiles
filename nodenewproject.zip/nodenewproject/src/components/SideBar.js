import React, {Component} from 'react';

var Constant = require('../constants');

export default class SideBar extends Component {
    
    closeNav = () => {
        
        if (document.getElementById("mySidenav") ) {
            document.getElementById("mySidenav").style.width = "0";
            
        }
    };

  showmenu = () => {
    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;

    for (i = 0; i < dropdown.length; i++) {
      dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
          dropdownContent.style.display = "none";
        } else {
          dropdownContent.style.display = "block";
        }
      });
    }
  }
    
    render(){
        return (
            <div id="mySidenav" className="sidenav">
            
            <a href="#" className="closebtn" onClick={this.closeNav}>&times;</a>
            <div className="side_box">
				<a className="side_txt active" href="Dashboard" ><i className="fa fa-dashboard"></i>Dashboard</a>
				<a className="dropdown-btn side_txt" onClick={this.showmenu}>
					<i className="fa fa-users"></i>Users
					<i className="fa fa-caret-down"></i>
				</a>
				
				
            </div>
            </div>
        )
    }
}